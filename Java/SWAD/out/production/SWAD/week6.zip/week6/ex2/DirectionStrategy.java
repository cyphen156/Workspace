package week6.ex2;
abstract public class DirectionStrategy {
	abstract public void move(Ball ball);
}
