package week6.ex2;
abstract public class DrawStrategy {
	abstract public void draw(Ball ball);
}
