package week6.ex1;

interface PricePolicy {
    public int calcPrice(int price, int n);
}
